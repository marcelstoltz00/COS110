#include "Polynomial.h"


void testTerm()
{
Term term1;
    std::cout << "Default Constructor: " << term1 << std::endl; 

    

    char variables1[] = {'z', 'x'};
    int powers1[] = {2, 2};
    Term term2(5, 2, variables1, powers1);
    std::cout << "Parameterized Constructor: " << term2 << std::endl;  

    char variables4[] = {'z', 'x'};
    int powers4[] = {0, 2};
    Term term9(5, 2, variables1, powers1);
    std::cout << "Parameterized Constructor: " << term2 << std::endl;  


    Term term3(term2);
    std::cout << "Copy Constructor: " << term3 << std::endl;  


    Term term4;
    term4 = term2;
    std::cout << "Assignment Operator: " << term4 << std::endl;  

    char variables2[] = {'x', 'z'};
    int powers2[] = {1, 2};
    Term term5(3, 2, variables2, powers2);
    Term term6 = term2 * term5;
    std::cout << "Multiplication Operator: " << term6 << std::endl; 

    term2 *= term5;
    std::cout << "Multiplication Assignment Operator: " << term2 << std::endl; 

    std::cout << "Equality Operator: " << (term3 == term4) << std::endl;  

    std::cout << "Less Than Operator: " << (term4 < term5) << std::endl;  

    std::cout << "Greater Than Operator: " << (term5 > term2) << std::endl;  

    std::cout << "Negation Operator: " << !term2 << std::endl;  

    std::cout << "Subscript Operator: Power of first variable (x) in term2: " << term2[0]<<term2[-1]<<term2[1] << std::endl;  

    std::cout << "Output Operator: " << term2 << std::endl;  

};
void testPolynomials()
{
    Polynomial poly1;
    std::cout << "Empty Polynomial: " << poly1 << std::endl;

    char vars1[] = {'x', 'y'};
    int pows1[] = {1, 2};
    Term term1(4, 2, vars1, pows1);

    char vars2[] = {'x', 'y'};
    int pows2[] = {1, 2};
    Term term2(3, 2, vars2, pows2);

    Term term3(5, 1, vars1, pows1);

    Polynomial poly2(term1);
    Polynomial poly3(term2);
    Polynomial poly19(poly2);

  

    std::cout << "Polynomial 2: " << poly2 << std::endl;
    std::cout << "Polynomial 3: " << poly3 << std::endl;

    Polynomial sumPoly = poly2 + poly3;
    Polynomial diffPoly = poly2 - poly3;
    Polynomial prodPoly = poly2 * poly3;

    std::cout << "Sum Polynomial: " << sumPoly << std::endl;
    std::cout << "Difference Polynomial: " << diffPoly <<diffPoly[1]<< std::endl;
    std::cout << "Product Polynomial: " << prodPoly << std::endl;

    poly2 += poly3;
    std::cout << "Poly2 after += Poly3: " << poly2 << std::endl;

    poly2 -= poly3;
    std::cout << "Poly2 after -= Poly3: " << poly2 << std::endl;

    poly2 *= poly3;
    std::cout << "Poly2 after *= Poly3: " << poly2 << std::endl;
};

int main()
{
    testTerm();
     testPolynomials();
    // testOperations();
    // cas();

    return 0;
}